<?php 

define('HOST', 'localhost');
define('USER', 'root');
define('PASS', 'aluno');
define('BASE', 'banco_enzo');

$conn = new MySQLi(HOST, USER, PASS, BASE);
?>