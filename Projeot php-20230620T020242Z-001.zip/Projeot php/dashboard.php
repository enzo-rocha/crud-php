<?php 

session_start();

if (empty($_SESSION)) {
print "<script> location.href='index.php'; </script>";
}

?>

<!DOCTYPE html>
<html>
<head>
  <style>
    body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
}

header {
  background-color: #333;
  color: #fff;
  padding: 10px;
}

.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logout-btn {
  background-color: #f44336;
  color: #fff;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.logout-btn:hover {
  background-color: #d32f2f;
}

.content {
  padding: 20px;
}

  </style>
</head>
<body>
  <header>
    <div class="navbar">
      <h1>Minha Aplicação</h1>
<form action="logout.php">
      <button class="logout-btn">Logout</button>
      </form>
    </div>
  </header>
  
  <div class="content">
    <!-- Conteúdo da sua página -->
  </div>
</body>
</html>
